import React from 'react'

const Dashboad = () => {
    return (
        <div>Dashboad</div>
    )
}

export default Dashboad